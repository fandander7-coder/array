// Ejercicio 15. Cobertura de domicilios
(function () {
  const ENVIO_GRATIS_HASTA = 3;
  const COBERTURA_MAXIMA = 10;

  function leerDistancias(cantidad) {
    let distancias = [];
    for (let i = 0; i < cantidad; i++) {
      distancias.push(Number(prompt("Ej 15 - Distancia " + (i + 1) + ":")));
    }
    return distancias;
  }

  function obtenerEnvioGratis(distancias) {
    return distancias.filter((d) => d <= ENVIO_GRATIS_HASTA); // 3 km exactos es gratis
  }

  function contarConEnvio(distancias) {
    return distancias.filter((d) => d > ENVIO_GRATIS_HASTA && d <= COBERTURA_MAXIMA).length;
  }

  function buscarPrimeroFuera(distancias) {
    return distancias.find((d) => d > COBERTURA_MAXIMA);
  }

  // Copiada del ejercicio 2
  function unirConComas(lista) {
    let texto = "";
    for (let i = 0; i < lista.length; i++) {
      if (i > 0) {
        texto = texto + ", ";
      }
      texto = texto + lista[i];
    }
    return texto;
  }

  console.log("=== Ejercicio 15: Cobertura de domicilios ===");
  let cantidad = Number(prompt("Ej 15 - ¿Cuántos pedidos?"));
  let distancias = leerDistancias(cantidad);

  let gratis = obtenerEnvioGratis(distancias);
  if (gratis.length === 0) {
    console.log("Envío gratis (0): (ninguno)");
  } else {
    console.log("Envío gratis (" + gratis.length + "): " + unirConComas(gratis));
  }

  console.log("Pagan envío: " + contarConEnvio(distancias));

  let primeroFuera = buscarPrimeroFuera(distancias);
  if (primeroFuera === undefined) {
    console.log("Todos los pedidos están en cobertura");
  } else {
    console.log("Primer pedido fuera de cobertura: " + primeroFuera + " km");
  }
})();
