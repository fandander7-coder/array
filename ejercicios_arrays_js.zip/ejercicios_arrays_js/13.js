// Ejercicio 13. La lista con forEach
(function () {
  // Copiada del ejercicio 1
  function leerProductos(cantidad) {
    let productos = [];
    for (let i = 0; i < cantidad; i++) {
      productos.push(prompt("Ej 13 - Producto " + (i + 1) + ":"));
    }
    return productos;
  }

  // Versión con forEach: el segundo parámetro del callback es el índice
  function mostrarLista(productos) {
    console.log("Lista del mercado:");
    productos.forEach((producto, i) => {
      console.log((i + 1) + ". " + producto);
    });
    console.log("Total: " + productos.length + " productos");
  }

  console.log("=== Ejercicio 13: La lista con forEach ===");
  let cantidad = Number(prompt("Ej 13 - ¿Cuántos productos?"));
  let productos = leerProductos(cantidad);
  mostrarLista(productos);
})();

/*
  Respuesta: NO, un forEach no se puede detener a la mitad. No acepta break,
  y un return dentro del callback solo termina esa vuelta, no el recorrido
  completo. En existeEnLista el return true sí cortaba el ciclo for.
  Por eso forEach sirve cuando hay que visitar TODOS los elementos (mostrar,
  acumular). Cuando hay que parar apenas se cumpla algo (buscar), conviene
  usar for, while o find.
*/
