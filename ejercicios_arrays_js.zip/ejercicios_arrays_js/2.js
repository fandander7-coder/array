// Ejercicio 2. Notas del grupo
(function () {
  const APRENDICES = 5; // para probar, cambia temporalmente a 3

  function leerNotaValida(numero) {
    let nota = Number(prompt("Ej 2 - Nota " + numero + ":"));
    // la condición está escrita al revés para que NaN también se rechace
    while (!(nota >= 0 && nota <= 5)) {
      console.log("Nota inválida, debe estar entre 0 y 5");
      nota = Number(prompt("Ej 2 - Nota " + numero + ":"));
    }
    return nota;
  }

  function calcularPromedio(numeros) {
    let suma = 0;
    for (let i = 0; i < numeros.length; i++) {
      suma = suma + numeros[i];
    }
    return suma / numeros.length;
  }

  function unirConComas(lista) {
    let texto = "";
    for (let i = 0; i < lista.length; i++) {
      if (i > 0) {
        texto = texto + ", ";
      }
      texto = texto + lista[i];
    }
    return texto;
  }

  console.log("=== Ejercicio 2: Notas del grupo ===");
  let notas = [];
  for (let i = 0; i < APRENDICES; i++) {
    notas.push(leerNotaValida(i + 1));
  }
  let promedio = calcularPromedio(notas);
  console.log("Notas: " + unirConComas(notas));
  console.log("Promedio: " + promedio.toFixed(1));
  if (promedio >= 3) {
    console.log("El grupo aprobó");
  } else {
    console.log("El grupo no aprobó");
  }
})();
