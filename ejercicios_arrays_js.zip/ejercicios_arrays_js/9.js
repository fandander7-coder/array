// Ejercicio 9. Al revés sin reverse
(function () {
  function leerPalabras(cantidad) {
    let palabras = [];
    for (let i = 0; i < cantidad; i++) {
      palabras.push(prompt("Ej 9 - Palabra " + (i + 1) + ":"));
    }
    return palabras;
  }

  function invertir(lista) {
    let invertida = [];
    for (let i = lista.length - 1; i >= 0; i--) {
      invertida.push(lista[i]);
    }
    return invertida;
  }

  // Copiada del ejercicio 2
  function unirConComas(lista) {
    let texto = "";
    for (let i = 0; i < lista.length; i++) {
      if (i > 0) {
        texto = texto + ", ";
      }
      texto = texto + lista[i];
    }
    return texto;
  }

  console.log("=== Ejercicio 9: Al revés sin reverse ===");
  let cantidad = Number(prompt("Ej 9 - ¿Cuántas palabras?"));
  let palabras = leerPalabras(cantidad);
  let invertidas = invertir(palabras);
  console.log("Original: " + unirConComas(palabras));
  console.log("Invertido: " + unirConComas(invertidas));
})();
