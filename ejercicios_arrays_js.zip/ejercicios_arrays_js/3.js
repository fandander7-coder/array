// Ejercicio 3. Primero, último y del medio
(function () {
  function leerCantidadMinimaUno() {
    let cantidad = Number(prompt("Ej 3 - ¿Cuántos números?"));
    while (!(cantidad >= 1) || Math.floor(cantidad) !== cantidad) {
      console.log("Debe ser un entero de al menos 1");
      cantidad = Number(prompt("Ej 3 - ¿Cuántos números?"));
    }
    return cantidad;
  }

  function leerNumeros(cantidad) {
    let numeros = [];
    for (let i = 0; i < cantidad; i++) {
      numeros.push(Number(prompt("Ej 3 - Número " + (i + 1) + ":")));
    }
    return numeros;
  }

  function obtenerUltimo(numeros) {
    return numeros[numeros.length - 1];
  }

  function mostrarMedio(numeros) {
    let n = numeros.length;
    if (n % 2 === 1) {
      // impar: un solo elemento del medio, en el índice floor(n / 2)
      console.log("Del medio: " + numeros[Math.floor(n / 2)]);
    } else {
      // par: dos del medio, en los índices n/2 - 1 y n/2
      console.log("Del medio: " + numeros[n / 2 - 1] + " y " + numeros[n / 2]);
    }
  }

  console.log("=== Ejercicio 3: Primero, último y del medio ===");
  let cantidad = leerCantidadMinimaUno();
  let numeros = leerNumeros(cantidad);
  console.log("Primero: " + numeros[0]);
  console.log("Último: " + obtenerUltimo(numeros));
  mostrarMedio(numeros);
})();
