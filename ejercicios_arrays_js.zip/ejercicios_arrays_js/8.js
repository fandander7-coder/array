// Ejercicio 8. Ventas sobre el promedio
(function () {
  let dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];

  // Copiada del ejercicio 4
  function leerVentas(dias) {
    let ventas = [];
    for (let i = 0; i < dias.length; i++) {
      ventas.push(Number(prompt("Ej 8 - Venta del " + dias[i] + ":")));
    }
    return ventas;
  }

  // Copiada del ejercicio 2
  function calcularPromedio(numeros) {
    let suma = 0;
    for (let i = 0; i < numeros.length; i++) {
      suma = suma + numeros[i];
    }
    return suma / numeros.length;
  }

  function contarMayoresQue(numeros, limite) {
    let cantidad = 0;
    for (let i = 0; i < numeros.length; i++) {
      if (numeros[i] > limite) {
        cantidad++;
      }
    }
    return cantidad;
  }

  function mostrarDiasSobre(dias, ventas, limite) {
    for (let i = 0; i < ventas.length; i++) {
      if (ventas[i] > limite) {
        console.log(dias[i] + ": $" + ventas[i]);
      }
    }
  }

  console.log("=== Ejercicio 8: Ventas sobre el promedio ===");
  let ventas = leerVentas(dias);
  // primero el promedio (primer recorrido), después la comparación (segundo recorrido)
  let promedio = Math.round(calcularPromedio(ventas));
  console.log("Promedio diario: $" + promedio);
  console.log("Días por encima del promedio:");
  mostrarDiasSobre(dias, ventas, promedio);
  console.log("Total: " + contarMayoresQue(ventas, promedio) + " días");
})();
