// Ejercicio 10. Pares e impares
(function () {
  const CANTIDAD = 8; // para probar, cambia temporalmente a 3

  function leerEnteros(cantidad) {
    let numeros = [];
    for (let i = 0; i < cantidad; i++) {
      numeros.push(Number(prompt("Ej 10 - Número " + (i + 1) + ":")));
    }
    return numeros;
  }

  function esPar(numero) {
    return numero % 2 === 0; // -3 % 2 da -1, nunca 0, así que -3 se reconoce como impar
  }

  function filtrarPares(numeros) {
    let pares = [];
    for (let i = 0; i < numeros.length; i++) {
      if (esPar(numeros[i])) {
        pares.push(numeros[i]);
      }
    }
    return pares;
  }

  function filtrarImpares(numeros) {
    let impares = [];
    for (let i = 0; i < numeros.length; i++) {
      if (!esPar(numeros[i])) {
        impares.push(numeros[i]);
      }
    }
    return impares;
  }

  // Copiada del ejercicio 2
  function unirConComas(lista) {
    let texto = "";
    for (let i = 0; i < lista.length; i++) {
      if (i > 0) {
        texto = texto + ", ";
      }
      texto = texto + lista[i];
    }
    return texto;
  }

  function mostrarGrupo(titulo, lista) {
    if (lista.length === 0) {
      console.log(titulo + " (0): (ninguno)");
    } else {
      console.log(titulo + " (" + lista.length + "): " + unirConComas(lista));
    }
  }

  console.log("=== Ejercicio 10: Pares e impares ===");
  let numeros = leerEnteros(CANTIDAD);
  mostrarGrupo("Pares", filtrarPares(numeros));
  mostrarGrupo("Impares", filtrarImpares(numeros));
})();
