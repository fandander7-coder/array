// Ejercicio 4. La semana de ventas
(function () {
  let dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];

  function leerVentas(dias) {
    let ventas = [];
    for (let i = 0; i < dias.length; i++) {
      ventas.push(Number(prompt("Ej 4 - Venta del " + dias[i] + ":")));
    }
    return ventas;
  }

  function calcularTotal(numeros) {
    let suma = 0;
    for (let i = 0; i < numeros.length; i++) {
      suma = suma + numeros[i];
    }
    return suma;
  }

  function mostrarReporte(dias, ventas) {
    for (let i = 0; i < dias.length; i++) {
      console.log(dias[i] + ": $" + ventas[i]);
    }
    console.log("Total semana: $" + calcularTotal(ventas));
  }

  console.log("=== Ejercicio 4: La semana de ventas ===");
  let ventas = leerVentas(dias);
  mostrarReporte(dias, ventas);
})();
