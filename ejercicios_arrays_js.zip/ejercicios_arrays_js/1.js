// Ejercicio 1. Lista del mercado
(function () {
  function leerProductos(cantidad) {
    let productos = [];
    for (let i = 0; i < cantidad; i++) {
      productos.push(prompt("Ej 1 - Producto " + (i + 1) + ":"));
    }
    return productos;
  }

  function mostrarLista(productos) {
    console.log("Lista del mercado:");
    for (let i = 0; i < productos.length; i++) {
      console.log((i + 1) + ". " + productos[i]); // índice 0 -> el usuario ve "1."
    }
    console.log("Total: " + productos.length + " productos");
  }

  console.log("=== Ejercicio 1: Lista del mercado ===");
  let cantidad = Number(prompt("Ej 1 - ¿Cuántos productos?"));
  let productos = leerProductos(cantidad);
  mostrarLista(productos);
})();
