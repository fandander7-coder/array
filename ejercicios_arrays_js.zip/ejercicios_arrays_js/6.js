// Ejercicio 6. Lista de invitados
(function () {
  let invitados = ["ana", "carlos", "luisa", "pedro", "sofía"];

  function existeEnLista(lista, valor) {
    for (let i = 0; i < lista.length; i++) {
      if (lista[i] === valor) {
        return true; // se detiene apenas lo encuentra
      }
    }
    return false;
  }

  console.log("=== Ejercicio 6: Lista de invitados ===");
  let entraron = 0;
  let rechazados = 0;
  let nombre = prompt("Ej 6 - Nombre (fin para terminar):");
  while (nombre !== "fin") {
    if (existeEnLista(invitados, nombre)) {
      console.log(nombre + " puede entrar");
      entraron++;
    } else {
      console.log(nombre + " no está en la lista");
      rechazados++;
    }
    nombre = prompt("Ej 6 - Nombre (fin para terminar):");
  }
  console.log("Entraron: " + entraron);
  console.log("Rechazados: " + rechazados);
})();
