// Ejercicio 12. Rotar la fila
(function () {
  function leerPersonas(cantidad) {
    let personas = [];
    for (let i = 0; i < cantidad; i++) {
      personas.push(prompt("Ej 12 - Persona " + (i + 1) + ":"));
    }
    return personas;
  }

  // Rotar k a la derecha: el elemento de la posición i llega a (i + k) % n.
  // Al construir el array nuevo con push, la posición j recibe el elemento
  // que estaba en (j - k) mod n. Con % se cubre k mayor que n.
  function rotarDerecha(lista, k) {
    let n = lista.length;
    let rotada = [];
    if (n === 0) {
      return rotada;
    }
    let desplazamiento = k % n;
    for (let j = 0; j < n; j++) {
      rotada.push(lista[(j - desplazamiento + n) % n]);
    }
    return rotada;
  }

  // Copiada del ejercicio 2
  function unirConComas(lista) {
    let texto = "";
    for (let i = 0; i < lista.length; i++) {
      if (i > 0) {
        texto = texto + ", ";
      }
      texto = texto + lista[i];
    }
    return texto;
  }

  console.log("=== Ejercicio 12: Rotar la fila ===");
  let cantidad = Number(prompt("Ej 12 - ¿Cuántas personas?"));
  let fila = leerPersonas(cantidad);
  let k = Number(prompt("Ej 12 - ¿Cuántas posiciones rotar?"));
  console.log("Fila original: " + unirConComas(fila));
  console.log("Fila rotada: " + unirConComas(rotarDerecha(fila, k)));
})();
