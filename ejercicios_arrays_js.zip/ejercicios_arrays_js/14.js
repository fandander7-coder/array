// Ejercicio 14. Precios con IVA
(function () {
  const IVA = 0.19;

  function leerPrecios(cantidad) {
    let precios = [];
    for (let i = 0; i < cantidad; i++) {
      precios.push(Number(prompt("Ej 14 - Precio " + (i + 1) + ":")));
    }
    return precios;
  }

  function calcularConIva(precio) {
    return Math.round(precio * (1 + IVA));
  }

  function aplicarIvaConMap(precios) {
    return precios.map((precio) => calcularConIva(precio));
  }

  function aplicarIvaConFor(precios) {
    let conIva = [];
    for (let i = 0; i < precios.length; i++) {
      conIva.push(calcularConIva(precios[i]));
    }
    return conIva;
  }

  function sonIguales(a, b) {
    if (a.length !== b.length) {
      return false;
    }
    for (let i = 0; i < a.length; i++) {
      if (a[i] !== b[i]) {
        return false;
      }
    }
    return true;
  }

  // Copiada del ejercicio 4
  function calcularTotal(numeros) {
    let suma = 0;
    for (let i = 0; i < numeros.length; i++) {
      suma = suma + numeros[i];
    }
    return suma;
  }

  // Copiada del ejercicio 2
  function unirConComas(lista) {
    let texto = "";
    for (let i = 0; i < lista.length; i++) {
      if (i > 0) {
        texto = texto + ", ";
      }
      texto = texto + lista[i];
    }
    return texto;
  }

  console.log("=== Ejercicio 14: Precios con IVA ===");
  let cantidad = Number(prompt("Ej 14 - ¿Cuántos productos?"));
  let precios = leerPrecios(cantidad);
  let conIvaMap = aplicarIvaConMap(precios);
  let conIvaFor = aplicarIvaConFor(precios);
  console.log("Sin IVA: " + unirConComas(precios)); // map no modificó el original
  console.log("Con IVA: " + unirConComas(conIvaMap));
  console.log("Total con IVA: $" + calcularTotal(conIvaMap));
  console.log("¿map y for dan lo mismo? " + sonIguales(conIvaMap, conIvaFor));
})();
