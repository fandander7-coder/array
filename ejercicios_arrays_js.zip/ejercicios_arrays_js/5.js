// Ejercicio 5. El día de mejor venta
(function () {
  let dias = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];

  // Copiada del ejercicio 4
  function leerVentas(dias) {
    let ventas = [];
    for (let i = 0; i < dias.length; i++) {
      ventas.push(Number(prompt("Ej 5 - Venta del " + dias[i] + ":")));
    }
    return ventas;
  }

  function buscarPosicionMayor(numeros) {
    let posicion = 0; // se arranca con el primer elemento, no con 0 como valor
    for (let i = 1; i < numeros.length; i++) {
      if (numeros[i] > numeros[posicion]) {
        posicion = i;
      }
    }
    return posicion;
  }

  function buscarPosicionMenor(numeros) {
    let posicion = 0;
    for (let i = 1; i < numeros.length; i++) {
      if (numeros[i] < numeros[posicion]) {
        posicion = i;
      }
    }
    return posicion;
  }

  console.log("=== Ejercicio 5: El día de mejor venta ===");
  let ventas = leerVentas(dias);
  let mejor = buscarPosicionMayor(ventas);
  let peor = buscarPosicionMenor(ventas);
  console.log("Mejor día: " + dias[mejor] + " ($" + ventas[mejor] + ")");
  console.log("Peor día: " + dias[peor] + " ($" + ventas[peor] + ")");
  console.log("Diferencia: $" + (ventas[mejor] - ventas[peor]));
})();
