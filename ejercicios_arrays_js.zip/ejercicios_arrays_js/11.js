// Ejercicio 11. Sin repetidos
(function () {
  const CANTIDAD = 10; // para probar, cambia temporalmente a 3

  function leerNumeros(cantidad) {
    let numeros = [];
    for (let i = 0; i < cantidad; i++) {
      numeros.push(Number(prompt("Ej 11 - Número " + (i + 1) + ":")));
    }
    return numeros;
  }

  // Copiada del ejercicio 6
  function existeEnLista(lista, valor) {
    for (let i = 0; i < lista.length; i++) {
      if (lista[i] === valor) {
        return true;
      }
    }
    return false;
  }

  function eliminarRepetidos(numeros) {
    let sinRepetidos = [];
    for (let i = 0; i < numeros.length; i++) {
      // se busca en el array que se está construyendo, no en el original
      if (!existeEnLista(sinRepetidos, numeros[i])) {
        sinRepetidos.push(numeros[i]);
      }
    }
    return sinRepetidos;
  }

  // Copiada del ejercicio 2
  function unirConComas(lista) {
    let texto = "";
    for (let i = 0; i < lista.length; i++) {
      if (i > 0) {
        texto = texto + ", ";
      }
      texto = texto + lista[i];
    }
    return texto;
  }

  console.log("=== Ejercicio 11: Sin repetidos ===");
  let numeros = leerNumeros(CANTIDAD);
  let sinRepetidos = eliminarRepetidos(numeros);
  console.log("Sin repetidos: " + unirConComas(sinRepetidos));
  console.log("Se eliminaron " + (numeros.length - sinRepetidos.length) + " repetidos");
})();
