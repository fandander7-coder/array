// Ejercicio 7. Calificaciones de domicilios
(function () {
  const CALIFICACIONES = 10; // para probar, cambia temporalmente a 3

  function leerCalificacionValida(numero) {
    let calificacion = Number(prompt("Ej 7 - Calificación " + numero + " (1 a 5):"));
    while (!(calificacion >= 1 && calificacion <= 5) || Math.floor(calificacion) !== calificacion) {
      console.log("Calificación inválida, debe ser un entero entre 1 y 5");
      calificacion = Number(prompt("Ej 7 - Calificación " + numero + " (1 a 5):"));
    }
    return calificacion;
  }

  function contarPorEstrellas(calificaciones) {
    let contadores = [0, 0, 0, 0, 0]; // índice 0 = 1 estrella ... índice 4 = 5 estrellas
    for (let i = 0; i < calificaciones.length; i++) {
      let indice = calificaciones[i] - 1; // estrellas - 1 = índice
      contadores[indice] = contadores[indice] + 1;
    }
    return contadores;
  }

  function repetirCaracter(caracter, veces) {
    let texto = "";
    for (let i = 0; i < veces; i++) {
      texto = texto + caracter;
    }
    return texto;
  }

  // Copiada del ejercicio 5
  function buscarPosicionMayor(numeros) {
    let posicion = 0;
    for (let i = 1; i < numeros.length; i++) {
      if (numeros[i] > numeros[posicion]) {
        posicion = i;
      }
    }
    return posicion;
  }

  function mostrarGrafico(contadores) {
    for (let i = 0; i < contadores.length; i++) {
      let linea = "Estrellas " + (i + 1) + ":";
      if (contadores[i] > 0) {
        linea = linea + " " + repetirCaracter("*", contadores[i]);
      }
      linea = linea + " (" + contadores[i] + ")";
      console.log(linea);
    }
  }

  console.log("=== Ejercicio 7: Calificaciones de domicilios ===");
  let calificaciones = [];
  for (let i = 0; i < CALIFICACIONES; i++) {
    calificaciones.push(leerCalificacionValida(i + 1));
  }
  let contadores = contarPorEstrellas(calificaciones);
  mostrarGrafico(contadores);
  console.log("Más frecuente: " + (buscarPosicionMayor(contadores) + 1) + " estrellas");
})();
